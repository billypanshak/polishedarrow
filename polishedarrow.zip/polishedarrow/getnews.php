<?php
require_once("config.php");
require_once("pagination.class.php");
$db_handle = new DBController();
$perPage = new PerPage();

$sql = "SELECT * from app_news order by id DESC";
$paginationlink = "getnews.php?page=";	
$pagination_setting = $_GET["pagination_setting"];

$count = 0;				
$page = 1;

if(!empty($_GET["page"])) {
$page = $_GET["page"];
}

$start = ($page-1)*$perPage->perpage;
if($start < 0) $start = 0;

$query =  $sql . " limit " . $start . "," . $perPage->perpage; 
$faq = $db_handle->runQuery($query);

if(empty($_GET["rowcount"])) {
$_GET["rowcount"] = $db_handle->numRows($sql);
}

if($pagination_setting == "prev-next") {
	$perpageresult = $perPage->getPrevNext($_GET["rowcount"], $paginationlink,$pagination_setting);	
} else {
	$perpageresult = $perPage->getAllPageLinks($_GET["rowcount"], $paginationlink,$pagination_setting);	
}

$output = '';

?>
<script language="JavaScript" type="text/javascript">
function checkDelete(){
    return confirm('Are you sure you want to delete this post?');
}
</script>
<style>
.link {padding: 10px 15px;background: transparent;border:#bccfd8 1px solid;border-left:0px;cursor:pointer;color:#607d8b}
.disabled {cursor:not-allowed;color: #bccfd8;}
.current {background: #bccfd8;}
.first{border-left:#bccfd8 1px solid;}
.question {font-weight:bold;}
.answer{padding-top: 10px;}
#pagination{margin-top: 20px;padding-top: 30px;border-top: #F0F0F0 1px solid;}
.dot {padding: 10px 15px;background: transparent;border-right: #bccfd8 1px solid;}
#overlay {background-color: rgba(0, 0, 0, 0.6);z-index: 999;position: absolute;left: 0;top: 0;width: 100%;height: 100%;display: none;}
#overlay div {position:absolute;left:50%;top:50%;margin-top:-32px;margin-left:-32px;}
.page-content {padding: 20px;margin: 0 auto;}
.pagination-setting {padding:10px; margin:5px 0px 10px;border:#bccfd8  1px solid;color:#607d8b;}

</style>

<table id="myTable" class="table table-hover news_table">
												<thead>
													<tr>  <th>Title</th>
														<th>Image</th>
														<th>Date</th>
														<th>Program</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													
											<?php 
											
											if (is_array($faq) || is_object($faq))
{ foreach($faq as $k=>$v) {  
											$date = date("d",strtotime($faq[$k]['date']));
											$month = date("F",strtotime($faq[$k]['date']));
											$year = date("Y",strtotime($faq[$k]['date']));

											$cat_id = $faq[$k]['category'];

											if($cat_id != ''){
												$cat_query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$cat_id."'");
												while($cat_data = mysqli_fetch_array($cat_query)){
													$cat_name = $cat_data['category_name']; 
												}
											}
													?>
										<tr>
											<td class="all_titles"><?php echo ucfirst($faq[$k]['title']);  ?></td>
											<td><img class="img-responsive" width="80" height="80" src="<?php echo $faq[$k]['image']; ?>"></td>
														<td><?php echo $date." ".$month.",".$year; ?></td>
														<td><?php echo $cat_name; ?></td>
														<td>
															<a class="ok2" href="post-view.php?id=<?php echo base64_encode($faq[$k]['id']); ?>"><i class="fa fa-search" aria-hidden="true"></i>(View)</a>
														</td>
													</tr>
										<?php $count = $count + 1; $cat_id = ''; $cat_name= ''; 
									}
									}else { echo '<center><font color="red">No available post.</font></center>'; }?> 
												</tbody>
											</table>
											<div class="col-md-12">
												<?php
if(!empty($perpageresult)) {
$output .= '<div id="pagination">' . $perpageresult . '</div>';
}
print $output;
?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
<script>
function myFunction() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

		   
		   
						