<?php
include "../config.php";

$fetch_news = mysqli_query($con,"SELECT * FROM `app_news` ORDER BY date DESC");
while($row = mysqli_fetch_assoc($fetch_news)){

$string = $row['description'];
$row['description'] = htmlspecialchars_decode(str_replace("&quot;", "\"", $string));


$fetch_category = mysqli_query($con,"SELECT category_name FROM `app_category` where id='".$row['category']."'");
while($row_cat = mysqli_fetch_assoc($fetch_category)){
	$catName = $row_cat['category_name'];
	$row['category_name'] = $catName;
}


$newsData[] = $row;
}

$jsonNewsData = json_encode($newsData);
echo $jsonNewsData;

?>