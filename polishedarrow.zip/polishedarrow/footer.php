
<!-- // end .section -->
<footer class="fixed-bottom">
        <!-- Copyright removal is not prohibited! -->
        <center><small><font color="white">COPYRIGHT © 2020</font></small></center>
</footer>
