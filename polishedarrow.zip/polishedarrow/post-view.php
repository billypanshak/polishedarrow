<?php
	include "config.php";
	include "header.php"; 
if(isset($_GET['id'])){
	$news_id = $_GET['id'];
        $news_id=base64_decode($news_id);
	$view_query = mysqli_query($con,"SELECT * FROM `app_news` WHERE id='".$news_id."'");
	while($row = mysqli_fetch_array($view_query)){
		$title = $row['title'];
		$cat_id = $row['category'];
		$image = $row['image'];
		$date = $row['date'];
		$description = $row['description'];
	}
	$cat_query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$cat_id."'");
	while($cat_data = mysqli_fetch_array($cat_query)){
		$cat_name = $cat_data['category_name'];
	}
	
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	  <!-- Nav Menu -->

	  <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="index.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="index.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="index.php#services">SERVICES</a></li>
                                <li class="nav-item"> <a class="nav-link" href="index.php#contact">CONTACT</a></li>
                                <li class="nav-item"> <a class="nav-link" href="programs.php">PROGRAMS</a> </li>
                                <li class="nav-item"> <a class="nav-link active" href="post.php">POSTS<span class="sr-only">(current)</span></a></li>
                                <li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
   <!-- // end .section -->
   <div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
					<!-- //end -->
						<div class="outter-wp">
						<p class="lead"><?php echo ucfirst($title); ?></p>
											<div class="input-field col-md-12">
												<form method="post" class="col-md-12">
													<table class="table view_news">
														<tbody>
															<tr>
																
																<td>Date: <?php echo $date; ?></td>
															</tr>
															<tr>
																
																<td>Program: <?php echo ucfirst($cat_name); ?></td>
															</tr>
															<tr>
																
																<td><img class="img-responsive" width="200" height="150" src="<?php echo $image; ?>"></td>
															</tr>
															<tr>
																
																<td>
																	<p><?php echo htmlspecialchars_decode($description); ?></p>
																</td>
															</tr>
														</tbody>
													</table>
												</form>
												<a href="post.php"><button type="button" class="btn view_buttons">GO BACK</button></a>
											</div>
										</div>
									</div>
								</div>
								</div>
                            </div>
        <?php include "footer.php"?> 
             <!-- jQuery and Bootstrap -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="js/script.js"></script>
						
				
</body>
</html>

<?php
//}
?>