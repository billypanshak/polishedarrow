-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 09, 2021 at 08:59 AM
-- Server version: 5.7.33
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `churchco_polishedarrow`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_category`
--

CREATE TABLE `app_category` (
  `id` int(255) NOT NULL,
  `category_name` varchar(300) NOT NULL,
  `category_image` varchar(300) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_login`
--

CREATE TABLE `app_login` (
  `id` int(255) NOT NULL,
  `username` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_login`
--

INSERT INTO `app_login` (`id`, `username`, `email`, `password`, `active`) VALUES
(1, 'billypanshak', 'billypanshak@gmail.com', 'fa1d99bed60e66a6058f1dc2128f1029', 0),
(2, 'emma', 'emmy@gmail.com', 'fa1d99bed60e66a6058f1dc2128f1029', 0),
(3, 'manji', 'billymanji@gmail.com', 'fa1d99bed60e66a6058f1dc2128f1029', 0),
(4, '08108893638', 'greatestmedupin1@gmail.com', '3b39bab8bdb95bcb6dfe482abb8cdf73', 0),
(5, 'manjI123', 'manji@gmail.com', '25d55ad283aa400af464c76d713c07ad', 0),
(6, 'bindeponle@gmail.com', 'bindeponle@gmail.com', 'd98974348dbd488f346d856431432e2b', 0);

-- --------------------------------------------------------

--
-- Table structure for table `app_news`
--

CREATE TABLE `app_news` (
  `id` int(255) NOT NULL,
  `title` varchar(300) CHARACTER SET utf8 NOT NULL,
  `category` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(500) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `app_videos`
--

CREATE TABLE `app_videos` (
  `id` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `category` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `video` varchar(500) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `token` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `token`) VALUES
(21, 'eD3QI5BC_A4:APA91bFYx137ZweK3cPPXGnuMw7WGD0rMQm4EwinN0bGdrQGCfRUnpv9inLnSrsicLMB97RJnD-9QQjS6nReABun9HvNlA9mTQJLd7uaaByMk0WUP8sKNHjxZegtB-0jFar6d16HXN09'),
(22, 'cZBovMeCUUY:APA91bEQG9f0eYkRonGyxoZA90zhvj7Uv96gN1QfTe5FRXnLk5tuzEHMViXbZGhQrMt-_MD9lKDRm_JpeY8SnOc1hu7jQle4TFZlLgEQtbTz1ZVrIhGcQiBaZ9aD3V8W87iOmBB_fEuL'),
(23, 'cCtRodlfwN8:APA91bGZUwqqVtD9UKUGcV1x1ksGs_FI8NBnCcfMwQ-FFUbfcptX-It-m6tr_ado9OtaBc-uFTM10N00qzkq3U7wCN2atwZBziiwyw8yl5YMYrThTwgoCxjNwN0vKKOaeuMWim7X2mgx'),
(24, 'fndxZVzy91g:APA91bGiO6MxRcJN4_0wKshPb_4ht9DhqrOkt4GYHzX479G_dPQzsSCBO2z2H6ue7J00l9DyRs5AWR8QnUAJ-W8adJF2aq_bwTiPtifs76vKeGxzsKc5tNPo3q7T75IL7wz2Me17diwk'),
(25, 'c-v8hTEuss8:APA91bH4SfrcMkunJ3mLaT9vXqTgCp_rjuAyyoQQE951rG9rQqYUpqi9BIZTRIMueQ3oMst1eAdJQzAbtp1_4LUMkmZlA_fj5I8DkGeBdMHfSU5uJ7y3pO6ZInAn0hSxaEUekI-ElM-S'),
(26, 'ea0d_BjocmQ:APA91bEH4VF2gdXxkwubIBxKo9ackzruufcr19g5CmeT3ArwN6xIV9pXMG4cjNB9XC8BgZsBI-orV3x5r6p7fzZS8huioOar8J7G9b-QhnwjyAWVZJfA4NIOGZwoIU_i_lWtfis4zD5G'),
(27, 'fiAUwwpGSHE:APA91bGC_f6I6kvcefrJi5jtTh9P1TSKjsrT3w5P0aZN5N2-1gxBY4FhInKyzPGmLytaFZgTtcHh9NsxSQvFiHaCCNletzKEhz6XqgoG5euIXHqX0Pb5WGCOMpfa6HOMW8Hiu4e0s3gs'),
(28, 'cexHhDAOZAw:APA91bFF6wv9u2lb78Lw_Ub6KVb8DpdN9-OfwimK_U_zfAASinNc3v0q3QERbLEpQPB3Bachu_TV-JnaIuF7zo25WRC20n1Zy5CJawkrDTz0YaUarWQXoRU_7GfC9kL_0cLnsaXZEzVW'),
(29, 'eVOZE3rNZms:APA91bFaAUnNc82ldxlWIowH5_0wwQFruepknt_4xcvcUsieqGZ2bihemEi_Vfrw500nWEOVqs_ux1CIVjf04k3bFZ3ZL8e5QOrF9k7G6KwhyNP3RPvhD4GQuBvPN73ZNvYS0FLg2HNh'),
(30, 'cyR3f_pKj4U:APA91bFmKBpyJpMuFpGKCbkqQBicJQHF42LJEiNfjXptXa5PP8DlLYW9j-JpsoMUe7XUdzATPH-0a04YFx_hQeDiS1Q9E4HW45XKHDZ_PKEk2JnaFZOVTH6DhUGLngFKWRYGckGAopYB'),
(31, 'e7kha_F5gwk:APA91bGnhfFLPNBxeGL2-vtXVCKv6h27YKExzAkC6gAoC-oNYXPtmsfpbdLjJHko2ldrDlK3cFy7NzuR6QM0SqkxOKAZE2kUJT1GB_dDu6H0yR9-Er-VR6GGh3FcZRSx0rss9By0FEg1'),
(32, 'cMJ2ecC4qbs:APA91bGPDrLErZJcd9zC91M018NwgXMxHOOdOewZ--tFHlO9LXkeXVWUo_eSNRp_HtBuo5K0nc0GZyLV1yM3mPG4fUgyEwWcnvdwfV6ziCSUbHvnXhjYrUQ0I9FgH_qrj9qSW-w9k03L'),
(33, 'f-Xpr9p49gc:APA91bE5yfJkLH1Oy-TBq-mf0ZEWkuER9i9N_2UE57PaLEVSaSSF99Myp5LUclH7SCwgfOkRySlEsOXOkITjZFNrBH5RpU_lUTxbo4HgKiuoTQhODHWZBt2EWxzeXh8FnCQ5IezN3spV'),
(34, 'fGy_7gM5Egs:APA91bHwkyOckIqxr2oZEg1Hd4XqHcwsXtbq4gIaFW_y2nita8lGS67ECauv0LfDCh1Q4qI8YIF3lBKAOKFNKX26YuHXA1Mj_itKBBwgWkC910qnhBXJ68cLekyfAN1Mp2az0_dnlz0t'),
(35, 'dpRDYo6V57Q:APA91bECh6QwQEo017xbLRqq8NBVUbcgMupjKpwmA28UH6-NY8se3kUDCCOhsLOvM1vyIvKNzQ9mBe8Qf-zPmqB1SfngONF16i6MPqFyc2Udip_7QyfIzjXpEH3COBrc5fubZrxYkReK'),
(36, 'dCnIEOcnlHY:APA91bGcCQWk9-hZ-EQpTiZnfYodQUwviuHvy9ZGi5m7ArQzOyrx3pbQHaZOtDRxoEk7Ol8RDMA9UP5sTpNpdW11jtbWOCg1YPMmuJrH1kcQarXFLwdnhJRjDWrh3StH1jhpwLBN_rEl'),
(37, 'fTIRkbc0s1E:APA91bF7yHpYM-SetD68KRzb-yIKXYWa9N-LdbvPFe8r4pul2X0HmrRRNnAUQ6tw_B38I8v31rl_SKl87OOtOEghWzTiLyRGJ-2Mz4IrWgws7Z2GaGKxIomJPV0YAVeAXBMwIvPNx4qi'),
(38, 'c0uTM2Lr2no:APA91bGg9yBqFehZgxqhiLlsQ89ddN9Dezpg2wXvKEXHCRkRVvh4Su88StoVLyFfXbQzroApOiqYQxh4fpQsHAp5XBy9ghhcW3XScV3XtNHmaAeq1EMNR4I2H2KeRhri41ebaYtYl6T4'),
(39, 'dAQ0IFlV9ns:APA91bFcPfNJxZuz-sIa8sIuEUnhwRqhoagTEA_FFRyI4qibdnTy1oB1aZwr2uu0ANryEG3x6rfv3I8srhhNCBQEK79K5rcuxHdgc9LsvBXNh42eDFwfQzOkY-G6LBmd066KE0TMB3T3'),
(40, 'cSm88JXbZpk:APA91bF2jiger2ur74UTMcuNN440iZ3ILHVSrF6YJaquq9gxrH-PhzA0joYithgArDjYBfs1pkoMqDITA85QF8rm45gnIO6hmuqoDReuaWuv5KtniKRw8mEmy_kA_DqzkDVXFjriGthR'),
(41, 'ckJBLmauQWE:APA91bEHRw3rymdEUdMy4C8F73rTxanEpaZ3puQ7CdYxb_r-EshF9QD9wca_1CtcahOhmucseMiekxUrXd8qgKa3a9Q3O404aBw2f_EUAwPYj1idhER4N1WPTwQ8-FvgUKYvSrVYoX1h'),
(42, 'c6exVTd2MNA:APA91bHitXDnGN-t3qJN-0ZvjPqWBMJKz0ZwGamOD5Zu5PyNYKw6Zl-D5nEI-_WO4pXSkJgQog-ktI-F7hT9kxffLaEYWBsH_JfcqP7SN7YcutHWBLjeFo0tIVK-bZZ0IMt3gIvrwsKk'),
(43, 'd6AO4GXcBuo:APA91bGXsHhrSSkKOTQRuAo5D9lUBj6nCz6JfkMWDvUD9CVfKKx_GdQSuKXeZNSlsKNPXzLL817hrFLljmNgJY8scLJqhJwM_JR0fl6gxhoncdDsglIGDYpRmD6zpSSUpNy0sfP26hdp'),
(44, 'ddCMUhhPlkw:APA91bGyLm9-4HfZXIGunNfgrg9pn2StJ2cHnYEpcDl_71XgXXlCnJJsCNJ1EbCkMZTw7_kCyOVWlsHoK1-cVvkHyLlEL5WDpIg7054Jmn1wPonQr5XRINvAcDwYy3L2wF6EC88rfeUE'),
(45, 'c4MOIhK0imA:APA91bEalmfjtscq9G3G_9foPNj72lGe54k1FWy0RhK8QlhRJ__NjdSytoFIoM32vmpX62ev2wBdPv98RFVwnbSUTbIG8Y2H0Ld6WRcVv2TdlGBlW09xdx83dI8QuZvOlPtQO5asvLHE'),
(46, 'fHeeKcN7TKw:APA91bHizM-uSHUhHqtjITTOqWt-tqEkeNKseIepjwDqPLV_jbV1Tn1CDgRcvdXBSPw6ieBUrO_HdHD55i4qHovq3W1Kj0i3xeDZDEgH9Jqxia-Z926GB0NcX5I0XpNU5m6f7tDDMi7y'),
(47, 'cZaAdglqZK0:APA91bGANlms64cIQSjqz7YGjs9LsdqhpSs-mgkOBI_DK5VmYuYpWKnMWJpJ6mdpxgJJttAtLJgaGpXRgtBQz5kweygtEqQ1UqR8zWMfktRVm2BKOqLmMg-u0o4l-FcdbbSemc467o0Y'),
(48, 'fmz-wq99fag:APA91bGGRfLde_3ujTZw6lM74yh0LOoVirvRQk3s7-6KBtjlhzj9Q8xwU8cdVSxBCL_2XnJruIE3Vi3y5_-2tVU-xjEUHnSiJGDoXHVJHCqUeN-_AeV3pXl5Z6ltUvFchtfa4VuZbsqb'),
(49, 'fTxTmt16yh0:APA91bFdFqLTh5nSmwowyi1m6SZA0mnr_3S2KrGZHFGkaFwCmr045kj_q5burw5i5Xz-7OH4tbCxrd8XU_pfktq5EBiQ6qUESxiyGkidSSgAN9MDHNHnpT2cnzjosilt0ZFa4MSK8c5P'),
(50, 'dMqbtwin7TU:APA91bETKWJsbZUmXogy13p-454qR0C9JnWHyMTS6T9VvI29rPVj0mja_6WIFevpiGn_seOiz3aiOB7l4c5qBIbyw2ItdICKljIhrdYylmZnQCRNJdnq5OKjkzD6m8sv2-3RG9KwWJ2D'),
(51, 'ehnfnUILQhs:APA91bGfu-Q0KdorCz1x127TB7PfGctPwx7pLeGxbJBiP5PF_8MuBhgMi12_50IWo-b9TixfwSqZ2tChMFy3QKiy_x0ZblVOWzMtETjpNTNs3-VeeGqR--WMppaYMiE4UgPH9IGDi6oS'),
(52, 'ff02HgRgx_4:APA91bGU17rf0GgPVBfWEZnCDLXnOHwkNiXYpIJqxSy7sSYvblf8kFybYc2femzJN6lUyYEwdK8i36cdkU8F9z1eul2TAcUpD8laLB_dXp1xUitY5hWvNtzlMg70UcMRpOP7rVgECsiN'),
(53, 'cjjN0wXZIWA:APA91bHPmq_sI2oPD4nYEWSqdCwHUbpjhH5l10SNuTdcOlNqERUxTJLiFvFDJGFju_m66_YW4mauZb27Rx1qWEKVHZxDE5jyunkHKDONRfLf8hX2A2UJwYmeXQP8AwLDmONsn4Yf2R1l5PySor3OgJGPvk2I16O_rw'),
(54, 'e-mN9EvBqCA:APA91bH59EapmGRZdz5OTDHMwDKly0VjMkK63hps_inMWUNSC8qQYOQSCFe8Zz0lITuweuLjOTda_RVm0m290JuxBBXIK7nLelAlCmoW2rTns5Rxn42BcmoN1HWb_FlDAa0G07tVrfS0_m2VAXec2JjCdVqjL5VrvQ'),
(55, 'cCmNNfFGLVc:APA91bEpSfh7p0LUEL-DT8HyGzOZPekzyPrxrnkzdNVYgoLYf9M_ixUUaZOdaMQgrV4sOJx3jkfBFhvhbRAaH2G3ODFZSq_lnbKD5jCJ4cfMUdavGxaktJP7pem1V0AQGqNx4DASpDK7LM8OpeXBy-gatM5BvUyEzQ');

-- --------------------------------------------------------

--
-- Table structure for table `minutes`
--

CREATE TABLE `minutes` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `created` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `minutes`
--

INSERT INTO `minutes` (`id`, `filename`, `created`) VALUES
(3, '1-PTDF-scholarship-optimized.pdf', '2020-03-13'),
(4, '4-short and long term goals.docx', '2020-03-13'),
(5, '5-PTDF _ Programs Database.pdf', '2020-03-15'),
(6, '6-_Bimor_Billy.htm.pdf', '2020-03-15'),
(7, '7-_Billy_Manji.htm.pdf', '2020-03-15'),
(8, '8-IMG-20200311-WA0002.jpg', '2020-03-15'),
(9, '9-4996download.jpg', '2020-04-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_category`
--
ALTER TABLE `app_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_login`
--
ALTER TABLE `app_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_news`
--
ALTER TABLE `app_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_videos`
--
ALTER TABLE `app_videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `minutes`
--
ALTER TABLE `minutes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_category`
--
ALTER TABLE `app_category`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_login`
--
ALTER TABLE `app_login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `app_news`
--
ALTER TABLE `app_news`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `app_videos`
--
ALTER TABLE `app_videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `minutes`
--
ALTER TABLE `minutes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
