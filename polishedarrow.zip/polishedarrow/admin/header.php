
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Augment Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
  <!-- slide show code -->
	<script src="../others/js/bootstrap.min.js"></script>
   <!-- end of slide show -->   
<link rel="stylesheet" href="../others/css/footable.core.css">
        <link rel="stylesheet" href="../others/css/footable.metro.css">
        <script src="../others/js/jquery-1.11.3.min.js"></script>
        <script src="../others/js/footable.js"></script>
        <script src="../others/js/footable.paginate.js"></script>  
     
<link href="../others/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="../others/css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="../others/css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<!-- lined-icons -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="../others/css/icon-font.min.css" type='text/css' />
<!-- //lined-icons -->
<script src="../others/js/jquery-1.10.2.min.js"></script>
<script src="../others/js/amcharts.js"></script>	
<script src="../others/js/serial.js"></script>	
<script src="../others/js/light.js"></script>	
<script src="../others/js/radar.js"></script>	
<link href="../others/css/barChart.css" rel='stylesheet' type='text/css' />
<link href="../others/css/fabochart.css" rel='stylesheet' type='text/css' />
<!--clock init-->
<script src="../others/js/css3clock.js"></script>
<!--Easy Pie Chart-->
<!--skycons-icons-->
<script src="../others/js/skycons.js"></script>

<script src="../others/js/jquery.easydropdown.js"></script>

<!--//skycons-icons-->