<?php
/****************************************************************************/
/****************************************************************************/
//******** This is a project work designed by Billy Panshak Shippi*************/
//******** Student of the Department of Computer Science University of Jos**********//
//******** This is the index form that shows up on first launch of the application. It allows the user to login and access the application's home page************//
//******** to carryout content management privilleges...********** //
/****************************************************************************/
/****************************************************************************/

session_start();
error_reporting(0);
include "config.php";
?>
<?php	
if(isset($_POST['user_login'])){
	$user_email = $_POST['user_email'];
	$user_pwd = md5($_POST['user_pwd']);
	//$user_email=filter_var($user_email, FILTER_SANITIZE_EMAIL);
$remove[] = "'";
$remove[] = '"';
$remove[] = "="; // just as another example
	if($user_email != '' && $user_pwd !=''){
		$query = mysqli_query($con,"SELECT * FROM app_login WHERE email='".$user_email."' AND password='".$user_pwd."'");

		if(mysqli_num_rows($query) > 0 && mysqli_num_rows($query) == 1){
			while($row = mysqli_fetch_array($query)){
				/*if($row["active"]!= 1){
					$msg = '<font color=red size=3>Sorry,your account hasn\'t been activated!!<br>
							Please Contact the General Secretary of the Church for activation.</font>';
				}*/
				//else{
					$_SESSION['id'] = $row['id'];
					header("Location: dashboard.php");

				//}
				
			}
		}
		else{
			$msg = 'Invalid email address or password';
		}
	}
	else{
		$msg = "You need to enter username and password";
	}

}
?>	
<!doctype html>
<html lang="en">
<head>
   <?php include "header.php";?>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Centre for Learning and Adolescent Development">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                    </nav>
                </div>
            </div>
        </div>
    </div>
	<!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
						<div class="outter-wp">
							<div class="login">	
										<h5 class="inner-tittle t-inner">Admin Login</h5>
										<?php
											if(!empty($msg)){
												echo "<p class='login_error'>".$msg."</p>";
																	}
										?>											
										<form class="form-group col-md-7" method="post">
												<input type="text" class="text" placeholder="Enter email address here" name="user_email">
												<input type="password" placeholder="Enter Password here" name="user_pwd">
												<button type="submit" class="btn view_buttons" name="user_login">LOGIN</button>
											Forgotten <a class="ok2" href="#">Password</a>?
											<p class="sign">Do not have an account? <a class="ok2" href="register.php">SIGN UP</a></p>
										</form>
							</div>												
	<!--added divs--></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
include "../footer.php"
?>
<!-- jQuery and Bootstrap -->
<script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>

</body>
</html>