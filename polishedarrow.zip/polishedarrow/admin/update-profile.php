<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	$msg = '';
	include "config.php";
	include "header.php";
	$admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
	while($row = mysqli_fetch_array($admin_details)){
		$username = $row['username'];
		$email = $row['email'];
		$password = $row['password'];
	}
	if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$email = $_POST['email'];
		$old_pwd = md5($_POST['old_pwd']);
		$new_pwd = $_POST['new_pwd'];
		$confirm_pwd = $_POST['confirm_pwd'];
		$new_pwd_hash = md5($confirm_pwd);
		//code to check if email or username already exist
		//get all usernames and emails emails from the database and check if they already exist
			$result=mysqli_query($con,"SELECT * FROM app_login");
			if (!$result){
				//die("Database query failed: ".mysql_error());
				$msg ='<font color=blue size=4>Sorry! we are having a problem connecting to database.<br>
				Try again later</font>';
			}
			$bool=false;
			while($row = mysqli_fetch_array($result)){
					if($email == $row["email"]){
						$bool=true;
					}
				
				}

		//end of code

		 if($password != $old_pwd){
			$msg = "<p class='login_error'>Old Password entered is incorrect.</p>";
		}
		/*else if($bool==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</p></font>';
			}
		*/
	 	else if(strlen($_POST['new_pwd'])<6){
	 			$msg = '<font color=red size=3><p class="login_error">Your password must be atleast 6 characters </p></font>';
	 		}
		else if($new_pwd != $confirm_pwd){
			$msg = "<p class='login_error'>New password and confirm password do not match.</p>";
		}
		else if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false){
	 			$msg = '<font color=red size=3><p class="login_error">A valid email address is required</p></font>';
	 		}

	 	/*else if($bool2==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</p></font>';
			}
		else if($bool==true){
				$msg = '<font color=red size=3><p class="login_error">Sorry, the username</font> \' ' .$_POST['username']. ' \'<font color=red size=4>already exists!!</p></font>';
			}*/
		else{
			$update_admin = mysqli_query($con,"UPDATE `app_login` SET username='".$username."', email='".$email."', password='".$new_pwd_hash."' WHERE `id`= $session_user_id");
			if($update_admin){
				$msg = "<p class='success'>Your details have been updated successfully.</p>";
			}
		
	}
}
	
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#services">SERVICES</a></li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#contact">CONTACT</a></li>
                                <li class="nav-item"> <a class="nav-link "  href="programs.php">PROGRAMS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="post.php">POSTS</a> </li>
								<li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
								<li class="nav-item"><a class="nav-link active" href="#" class="btn btn-outline-light my-3 my-sm-0 ml-lg-3"><?php echo $username; ?><span class="sr-only">(current)</span></a></li>
                                <li class="nav-item"><a class ="nav-link" href="logout.php">LOGOUT</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
	<!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
					<!-- //end -->
						<div class="outter-wp">							
							<!--//outer-wp-->
							<p class="lead">Profile Update</p>
							<div class="card-panel">
								<div class="">
									<div class="row">
										<div class="col-md-12">
											<?php if($msg != ''){
													echo $msg;
												}
											?>
											<form method="post">
												<div class="form-group">
													<label for="username">Username:</label>
													<input type="text" name="username" class="form-control" id="username" value="<?php echo $username; ?>" required>
												</div>
												<div class="form-group">
													<label for="email">Email Address:</label>
													<input type="email" name="email" class="form-control" id="email" value="<?php echo $email; ?>" required>
												</div>
												<div class="form-group">
													<label for="old_pwd">Old Password:</label>
													<input type="password" name="old_pwd" class="form-control" id="old_pwd" required>
												</div>
												<div class="form-group">
													<label for="new_pwd">New Password:</label>
													<input type="password" name="new_pwd" class="form-control" id="new_pwd" required>
												</div>
												<div class="form-group">
													<label for="confirm_pwd">Confirm Password:</label>
													<input type="password" name="confirm_pwd" class="form-control" id="confirm_pwd" required>
												</div>
												<button type="submit" name="submit" class="btn btn-default right">UPDATE</button>
											</form>
										</div>
									</div>
									</div>
								</div>
							</div>
						</div>
					</div>
		</div>
	</div>
				<?php include "../footer.php"; ?>
	<script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>
				
</body>
</html>

<?php
}
?>