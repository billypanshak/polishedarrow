<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit;
  }
  else{
    include "config.php";
    include "header.php";
    $admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
	    while($row = mysqli_fetch_array($admin_details)){
        $username = $row['username'];
        $email = $row['email'];
	    } 
    
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
        <!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#services">SERVICES</a></li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#contact">CONTACT</a></li>
                                <li class="nav-item"> <a class="nav-link"  href="programs.php">PROGRAMS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="post.php">POSTS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
                                <li class="nav-item"><a class ="nav-link active"href="profile.php" class="btn btn-outline-light my-3 my-sm-0 ml-lg-3"><?php echo $username; ?><span class="sr-only">(current)</span></a></li>
                                <li class="nav-item"><a class ="nav-link" href="logout.php">LOGOUT</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- // end .section -->
    <div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
					<!-- //end -->
						<div class="outter-wp">
                            <p class="lead">Profile of: <?php echo ucfirst($username); ?></p>
							<!--//outer-wp-->
											<div class="input-field col-md-12">
												<form method="post" class="col-md-12">
													<table class="table view_news">
														<tbody>
															<tr>
																<td>Username: <?php echo $username; ?></td>
															</tr>
															<tr>
																<td>
																	<p>Email Address: <?php echo ($email); ?></p>
																</td>
															</tr>
														</tbody>
													</table>
												</form>
											</div>
							<a href="update-profile.php"><button type="button" class="btn view_buttons">UPDATE PROFILE/RESET PASSWORD</button></a>
							</div>
				</div>
			</div>
    <?php include "../footer.php"?> 
     <!-- jQuery and Bootstrap -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="js/script.js"></script>
				
</body>
</html>

<?php
}
?>