<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
		include "config.php";
		include "header.php";
		$admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
		while($row = mysqli_fetch_array($admin_details)){
		$username = $row['username'];
		}
		if($_GET['id'] != ''){
			$rand = rand();
			$msg = '';
			$id = $_GET['id'];
		$id=base64_decode($id);
			$query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$id."'");
			while($row = mysqli_fetch_array($query)){
				$category_name = $row['category_name'];
				$category_image = $row['category_image'];
				$description = htmlspecialchars_decode($row['description']);
			}
			
			if(isset($_POST['update_category'])){
				$category_name = $_POST['category_name'];
				$remove[] = "'";
				$remove[] = "`";
				$description = htmlspecialchars($_POST['editor1']);
				
				if($_FILES['category_image']['name']['description'] != ''){
					$category_image = $rand."_".$_FILES['category_image']['name'];
					$full_path = IMAGE_PATH.$category_image;
					$update = mysqli_query($con,"UPDATE app_category SET category_name='".$category_name."', category_image='".$full_path."', description='".$description."' WHERE id='".$id."'");
				}
				else{
					$update = mysqli_query($con,"UPDATE app_category SET category_name='".$category_name."', description='".$description."' WHERE id='".$id."'");
				}
				
				if($_FILES['category_image']['name'] != '' && $update != ''){
					$name = $rand."_".$_FILES['category_image']['name'];
					$size = $_FILES['category_image']['size'];
					$type = $_FILES['category_image']['type'];
					$tmp_name = $_FILES['category_image']['tmp_name'];


					if (isset($name)) 
					{
						if (!empty($name)) 
						{
							if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name))
								$msg = '<p class="success">Program updated Successfully. Please go <span class="back"><a href="programs.php">BACK</a></span></p>';
							else
								$msg = "<p class='login_error'>Program not updated</p>";
						}
						else 
						{
							$msg = '<p class="login_error">Please choose image</p>';
						}

					}
				}
				else if($update != ''){
					$msg = '<p class="success">Program updated Successfully! Please go <span class="back"><a href="programs.php">BACK</a></span></p>';
				}
			}

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->

    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#services">SERVICES</a></li>
								<li class="nav-item"> <a class="nav-link" href="dashboard.php#contact">CONTACT</a></li>
								<li class="nav-item"> <a class="nav-link active"  href="programs.php">PROGRAMS<span class="sr-only">(current)</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" href="post.php">POSTS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
                                <li class="nav-item"><a href="profile.php" class="btn btn-outline-light my-3 my-sm-0 ml-lg-3"><?php echo $username; ?></a></li>
                                <li class="nav-item"><a class ="nav-link" href="logout.php">LOGOUT</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
						<div class="outter-wp">
						<p class="lead">Edit <?php echo ucfirst($category_name); ?> Program</p>
							<!--//outer-wp-->
							<div class="card-panel">
									<div class="row">					
										<div class="col-md-12">
											<form method="post" enctype="multipart/form-data" id="category_form">
											<?php if($msg != ''){
													echo $msg;
												}
											?>
											<div class="form-group col-md-12">
												<label>Program Name</label>
												<input type="text" class="form-control" name="category_name" id="category_name" required value="<?php echo $category_name; ?>">
											</div>
											<div class="form-group col-md-12 image_show">
												<img class="img-responsive" width="150" height="150" src="<?php echo $category_image; ?>">
											</div>
											<div class="form-group col-md-12">
												<label>Image</label>
												<input type="file" name="category_image" id="category_image">
											</div>
                                            <div class="form-group col-md-12 ">
                                                <textarea name="editor1" id="editor1" rows="10" cols="80">
                                                    <?php echo $description; ?>
                                                </textarea>
                                                <script src="../others/ckeditor/ckeditor.js"></script>
                                                <script>
                                                    // Replace the <textarea id="editor1"> with a CKEditor
                                                    // instance, using default configuration.
                                                    CKEDITOR.replace( 'editor1' );
                                                </script>
                                            </div>
											<div class="col-md-12">
												<input type="submit" name="update_category" value="UPDATE" class="btn view_buttons">
											</div>
										</form>
										</div>
								</div>
							</div>
						
						
						 <!--footer section start-->
							<?php //include "footer.php"; ?>
						<!--footer section end-->
				
				<!--//content-inner-->
			<!--/sidebar-menu-->
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php include "../footer.php"; ?>							
	 <!-- jQuery and Bootstrap -->
	 <script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>		
</body>
</html>

<?php
	}
}
?>