<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	$msg = '';
	include "config.php";
	include "header.php";
	$admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
	while($row = mysqli_fetch_array($admin_details)){
		$username = $row['username'];
	}

if(isset($_GET['id'])){
	$news_id = $_GET['id'];
$news_id=base64_decode($news_id);
}
$rand = rand();
$view_query = mysqli_query($con,"SELECT * FROM `app_videos` WHERE id='".$news_id."'");
while($row = mysqli_fetch_array($view_query)){
	$title = $row['title'];
	$cat_id = $row['category'];
	$image = $row['video'];
	$date = $row['date'];
	$description = htmlspecialchars_decode($row['description']);
	
	$cat_query = mysqli_query($con,"SELECT * FROM app_category WHERE id ='".$cat_id."'");
	while($cat_data = mysqli_fetch_array($cat_query)){
		$cat_name = $cat_data['category_name'];
	}
}

if(isset($_POST['submit'])){
	$title1 = $_POST['news-title'];
$remove[] = "'";
$remove[] = "`";

 // just as another example
$title1 = str_replace( $remove, "", $title1 );   
        $title=htmlspecialchars($title1);
//echo $title;
	$cat_id = $_POST['news-category'];	
	$date = $_POST['news-date'];
	$description = htmlspecialchars($_POST['editor1']);
	
	if($_FILES['news-image']['name'] != ''){
		$image = $rand."_".$_FILES['news-image']['name'];
		$full_path = IMAGE_PATH.$image;
		$update = mysqli_query($con,"UPDATE app_news SET title='".$title."', category='".$cat_id."', date='".$date."', image='".$full_path."', description='".$description."' WHERE id='".$news_id."'") or mysqli_error();
	}
	else{
		$update = mysqli_query($con,"UPDATE app_news SET title='".$title."', category='".$cat_id."', date='".$date."',description='".$description."' WHERE id='".$news_id."'") or mysqli_error();
	}
	if($_FILES['news-image']['name'] != '' && $update != ''){
		$name = $rand."_".$_FILES['news-image']['name'];
		$size = $_FILES['news-image']['size'];
		$type = $_FILES['news-image']['type'];
		$tmp_name = $_FILES['news-image']['tmp_name'];


		 if (isset($name)) 
		{
			if (!empty($name)) 
			{
				if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name))
					$msg = '<p class="success">Post updated successfully. Please go <span class="back"><a href="post.php">BACK</a></span></p>';
				else
					$msg = "<p class='login_error'>Post not updated.</p>";
			}
		}
	}
	else if($update != ''){
		$msg = '<p class="success">Post updated successfully. Please go <span class="back"><a href="post.php">BACK</a></span></p>';
	}
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#services">SERVICES</a></li>
								<li class="nav-item"> <a class="nav-link" href="dashboard.php#contact">CONTACT</a></li>
								<li class="nav-item"> <a class="nav-link"  href="programs.php">PROGRAMS</a> </li>
                                <li class="nav-item"> <a class="nav-link active" href="post.php">POSTS<span class="sr-only">(current)</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" href="videos.php">VIDEOS</a> </li>
                                <li class="nav-item"><a href="profile.php" class="btn btn-outline-light my-3 my-sm-0 ml-lg-3"><?php echo $username; ?></a></li>
                                <li class="nav-item"><a class ="nav-link" href="logout.php">LOGOUT</a></li>
							</ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
	
         	 <div class="outter-wp">
			  <p class="lead">Edit <?php echo ucfirst($title); ?> Post</p>
			  	<div class="card-panel">
					<div class="row">					
						<div class="col-md-12">
							
						<form method="post" enctype="multipart/form-data">
							<?php if($msg != ''){
								echo $msg;
							}
							?>
							<div class="form-group col-md-12">
								<div class="form-group col-md-12">
									<label for="title">Title</label>
									<input type="text" name="news-title" value="<?php echo $title; ?>" class="form-control">
								</div>
								<div class="form-group col-md-12">
									<label>Program</label>
									<select name="news-category" class="form-control select_cat">
										<option value="">---------</option>
										<?php
								$cats = mysqli_query($con,"SELECT * FROM `app_category`");
								while($rows = mysqli_fetch_array($cats)){
										?>
										<option value="<?php echo $rows['id']; ?>" <?php if($cat_id == $rows['id']){ echo "selected = selected"; } ?>><?php echo ucfirst($rows['category_name']); ?></option>
								<?php } ?>
									</select>
								</div>
								<div class="form-group col-md-12">
									<label for="date">Date</label>
									<input type="date" name="news-date" value="<?php echo $date; ?>" class="form-control">
								</div>
								<div class="form-group col-md-12 image_show">
								<img class="img-responsive" width="150" height="150" src="<?php echo $image; ?>">
								</div>
								<div class="form-group col-md-12">
									<label for="image">Image</label>
									<input type="file" name="news-image" id="news-image">
								</div>
							</div>
							<div class="form-group col-md-12">
								<label>Description</label>
								<textarea name="editor1" id="editor1" rows="10" cols="80">
									<?php echo $description; ?>
								</textarea>
								<script src="../others/ckeditor/ckeditor.js"></script>
								<script>
									// Replace the <textarea id="editor1"> with a CKEditor
									// instance, using default configuration.
									CKEDITOR.replace( 'editor1' );
								</script>
							</div>
							<input type="submit" name="submit" value="UPDATE" class="btn view_buttons">
						</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
             <!--//outer-wp-->
                <!--footer section start-->
                <?php include "../footer.php"; ?>
       
    <!--//content-inner-->
    <!--/sidebar-menu-->
    <?php //include "sidebar.php"; ?>
 <!-- jQuery and Bootstrap -->
 <script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>
</body>
</html>

<?php
}
?>