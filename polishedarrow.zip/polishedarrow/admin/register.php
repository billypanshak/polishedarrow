<html><head><script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script></head></html>
<?php
session_start();
error_reporting(0);
include "config.php";
include "header.php";
?>
<?php
if(isset($_POST['register'])){
	$username =$_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password_again = $_POST['password_again'];
	$password_hash=md5($password);//encripting password
	//get all usernames and emails emails from the database and check if they already exist
			$result=mysqli_query($con,"SELECT * FROM app_login");
			if (!$result){
				//die("Database query failed: ".mysql_error());
				$msg ='<font color=blue size=4>Sorry! we are having a problem connecting to database.<br>
				Try again later</font>';
			}
			$bool=false;
			$bool2=false;
			while($row = mysqli_fetch_array($result)){
					if($email == $row["email"]){
						$bool2=true;
					}
					else if($username == $row["username"]){
						$bool=true;
					}
				
				}

	if(empty($username)==true || empty($email)==true || empty($password)==true || empty($password_again)==true){
			$msg = '<font color=red size=3>All fields are required!!</font>';

			
		}
			// checking if username exist
			else if($bool==true){
			$msg = '<font color=red size=3>Sorry, the username</font> \' ' .$_POST['username']. ' \'<font color=red size=4> already exists!!</font>';
			}
			//checking if email already exist
			else if($bool2==true){
				$msg = '<font color=red size=3>Sorry, the email</font> \' ' .$_POST['email']. ' \'<font color=red size=4> already exists!!</font>';
			}
	 		// checking user's password length
	 		else if(strlen($_POST['password'])<6){
	 			$msg = '<font color=red size=3>Your password must be atleast 6 characters</font>';
	 		}
	 		// checking user's password against password_again
	 		else if($_POST['password']!== $_POST['password_again']){
	 			$msg = '<font color=red size=3>Your passwords do not match</font>';
	 		}
	 		//Checking if email entered by user is a valid email address
	 		else if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false){
	 			$msg = '<font color=red size=3>A valid email address is required</font>';
	 		}
	 		

			else{
				$query=htmlentities(strip_tags(mysqli_query($con, "INSERT INTO app_login (username, email, password) VALUES ('{$username}', '{$email}', '{$password_hash}')")));
				//checking if user details have been inserted into the database successfully
				if($query=true){?>

						<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
							<script type="text/javascript">
						swal({
						title: "You have registered",
						text: "successfully ",
						icon: "success",button: "close"
						}).then(function() {
						//Redirect the user
						window.location.href = "index.php";
						//console.log('The Ok Button was clicked.');
						});
						</script>
				<?php	
				}else{
					$msg = '<font color=red size=3> SORRY, </font> \' ' .$_POST['email']. ' \'
					<font color=red size=3> we are unable to register you.<br> Please try again later!!</font>';
					header ("refresh:10; index.php" );
		}
	}
}
mysqli_close($con);

?>	
<!doctype html>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                    </nav>
                </div>
            </div>
        </div>
    </div>
	<!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
						<div class="outter-wp">
							<div class="login">	
										<h5 class="inner-tittle t-inner">Register an Admin</h5>
										<?php
											if(!empty($msg)){
												echo "<p class='registration_error'>".$msg."</p>";
																			}
										?>									
										<form class="form-group col-md-7" method="post">
												<input type="text" class="text" placeholder="Enter Username" name="username">		
												<input type="text" class="text" placeholder="Email Address" name="email">
												<input type="password" placeholder="Password" name="password">
												<input type="password" placeholder="Comfirm password" name="password_again">
												<button type="submit" class="btn view_buttons" name="register">SIGN UP</button>
												<input type="reset" value="Reset" color="red">
											<p class="sign">Already registered? <a class="ok2" href="index.php">LOGIN</a></p>
										</form>
							</div>
																			
	<!--added divs--></div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include "../footer.php"?>  
<!-- jQuery and Bootstrap -->
<script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>
			
</body>
</html>