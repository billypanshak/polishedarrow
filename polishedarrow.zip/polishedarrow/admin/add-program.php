<?php
error_reporting(0);
session_start();
$session_user_id=$_SESSION['id'];
if (!isset($_SESSION['id'])) {
  header("Location: index.php");
  exit;
}
else{
	//echo $_SESSION['id'];
	include "config.php";
	include "header.php";
	$admin_details = mysqli_query($con,"SELECT * FROM `app_login`  WHERE `id`= $session_user_id");
	while($row = mysqli_fetch_array($admin_details)){
		$username = $row['username'];
	}
$msg = '';
if(isset($_POST['add_category'])){
	$rand = rand();
	$category_name = $_POST['category_name'];
	$category_image = $rand."_".$_FILES['category_image']['name'];
	$full_path = IMAGE_PATH.$category_image;
	$editor1 = htmlspecialchars($_POST['editor1']);
	
	$category_insert = mysqli_query($con,"INSERT INTO app_category (category_name,category_image,description) VALUES('".$category_name."','".$full_path."','".$editor1."')");
	//$category_search=mysqli_query($con, "SELECT * FROM app_category");
		
	if($category_image != '' && $category_insert != ''){
		//$category_search=mysqli_query($con, "SELECT * FROM app_category");
		$category_search = mysqli_query($con,"SELECT * FROM app_category WHERE category_name='".$category_name."'");
		$name = $rand."_".$_FILES['category_image']['name'];
		$full_path = IMAGE_PATH.$name;
		$size = $_FILES['category_image']['size'];
		$type = $_FILES['category_image']['type'];
		$tmp_name = $_FILES['category_image']['tmp_name'];

		 if (isset($name)){
			if (!empty($name)) 
			{
				if(move_uploaded_file($tmp_name, PDF_UPLOADS. $name)){
					$msg = '<p class="success">New Program added successfully. <span class="back"><a href="programs.php">PREVIEW</a></span></p>';
					}
			}
			else 
			{
				$msg = "<p class='login_error'>Please choose a file.</p>";
			}

		}
	}
	else{
		$msg = "<p class='login_error'>Program  not inserted.</p>";
	}

}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Mobland - Mobile App Landing Page Template">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="../css/themify-icons.css">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="../css/style.css" rel="stylesheet">
</head>
<body data-spy="scroll" data-target="#navbar" data-offset="30">
	<!-- Nav Menu -->

    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php">HOME</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="dashboard.php#services">SERVICES</a></li>
								<li class="nav-item"> <a class="nav-link" href="dashboard.php#contact">CONTACT</a></li>
								<li class="nav-item"> <a class="nav-link active"  href="programs.php">PROGRAMS<span class="sr-only">(current)</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" href="post.php">POSTS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
                                <li class="nav-item"><a href="profile.php" class="btn btn-outline-light my-3 my-sm-0 ml-lg-3"><?php echo $username; ?></a></li>
                                <li class="nav-item"><a class ="nav-link" href="logout.php">LOGOUT</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- // end .section -->
	<div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="../images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                         <!-- // added code from churchconnect -->
                        <div class="outter-wp">
                            <p class="lead">ADD A PROGRAM CURRICULUM</p>
									<!--//outer-wp-->
														<div class="card-panel">
															<div class="row">
																<div class="row col-md-12">
																	<form method="post" enctype="multipart/form-data" id="category_form">
																		<?php if($msg != ''){
																			echo $msg;
																			}
																		?>
																		<div class="form-group col-md-12">
																			<label>Program Name</label>
																			<input type="text" class="form-control" name="category_name" id="category_name" required>
																		</div>
																		<div class="form-group col-md-12">
																			<label>Image</label>
																			<input type="file" name="category_image" id="category_image"  required>
																		</div>
																		
																		<div class="form-group col-md-12">
																			<label>Program Description/Details</label>
																			<textarea name="editor1" id="editor1" rows="10" cols="80">
																			</textarea>
																			<script src="../others/ckeditor/ckeditor.js"></script>
																			<script>
																					// Replace the <textarea id="editor1"> with a CKEditor
																					// instance, using default configuration.
																					
																			CKEDITOR.replace( 'editor1' );
																			</script>
																		</div>

																		<div class="col-md-12">
																			<input type="submit" name="add_category" value="SUBMIT" class="btn view_buttons">
																		</div>
																	</form>
																</div>
															</div>
											<!--//content-inner-->
										<!--/sidebar-menu-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php include "../footer.php"?> 
	 <!-- jQuery and Bootstrap -->
	 <script src="../js/jquery-3.2.1.min.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="../js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="../js/script.js"></script>
										
</body>
<?php
}
?>
</html>

