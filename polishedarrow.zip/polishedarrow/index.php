<?php
include "header.php";
?>
<!doctype html>
<html lang="en">
<head>
    <style>@import url(https://fonts.googleapis.com/css?family=Droid+Sans);
.loader {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url('http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif?e44397') 50% 50% no-repeat rgb(249,249,249);
}

</style>
<div class="loader"></div>
<script>$(window).load(function(){
     $('.loader').fadeOut();
});</script>
    <title>Polished Arrow</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Centre for Learning and Adolescent Development">
    <meta name="keywords" content="HTML5, bootstrap, mobile, app, landing, ios, android, responsive">

    <!-- Font -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Themify Icons -->
    <link rel="stylesheet" href="css/themify-icons.css">
     <!-- Owl carousel -->
     <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Main css -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="30">
    <!-- Nav Menu -->
    <div class="nav-menu fixed-top">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-dark navbar-expand-lg">
                        <a class="navbar-brand" href="#"><strong>POLISHED ARROW</strong></a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
                        <div class="collapse navbar-collapse" id="navbar">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item"> <a class="nav-link active" href="index.php">HOME <span class="sr-only">(current)</span></a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#about">ABOUT</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#services">SERVICES</a></li>
                                <li class="nav-item"> <a class="nav-link" href="#contact">CONTACT</a></li>
                                <li class="nav-item"> <a class="nav-link" href="programs.php">PROGRAMS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="post.php">POSTS</a> </li>
                                <li class="nav-item"> <a class="nav-link" href="#">VIDEOS</a> </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <header class="bg-gradient" id="home">
                <!--input slide show here-->
				<div class="container">
                    <div class="row">
						<div class="col-sm-12">
                            <div class="img-gallery owl-carousel owl-theme">
                                    <img src="slides/logo.jpg" alt="image">
                                    <img src="slides/slide1.jpg" alt="image">
                                    <img src="slides/slide2.jpg" alt="image">
                                    <img src="slides/slide3.jpg" alt="image">
                                    <img src="slides/slide4.jpg" alt="image">
                                    <img src="slides/slide5.jpg" alt="image">
                                    <img src="slides/slide6.jpg" alt="image">
                            </div>                      
                        </div>
                    </div>
                </div>
				<!--end of slide-->
    </header>
    <div class="section light-bg">
        <div class="container">
            <div class="tab-content">
                <div class="tab-pane fade show active">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                        <div>

                            <h2>WELCOME TO POLISHED ARROW</h2>
                            <p class="lead">Centre for Learning and Adolescent Development</p>
                            <p>
                                Polished arrow is an adolescent-friendly organization that is sensitive 
                                to the needs of the adolescent. We have an enabling environment that helps to 
                                identify the peculiarity of their need so that they can be met accordingly. 
                                At Polished arrow, we provide protective and corrective educational services
                                to inculcate a healthy mindset in them. Our educational services are also 
                                designed to improve the academic performance of these adolescents.  Our primary 
                                targets are in and out of school adolescents that are characterised by poor 
                                academic performance, unproductive with low IQ.
                            </p>
                            <p>
                                Being a learning and development centre, we help the adolescents to identify their greatest 
                                threat, weakness, strength, opportunities and uniqueness. We guide them into identifying the 
                                required skills and also help them to nurture those skills until it is fully developed. 
                                So that they can confidently manage “the daunting global challenges associated with their 
                                transition into adulthood”.
                            </p>
                            <p>
                                We are a catalyst of change, envisioned to manage disorder among adolescents. 
                            </p>
                            <p class="lead">Targeted Adolescents</p>
                            <ul class="list-group list-group-flush">
                                <div class="list-group-item"><p>Adolescents with average or poor academic performance<p></div>
                                <div class="list-group-item"><p>Adolescents between the ages  of 12-19 years</p></div>
                                <div class="list-group-item"><p>Adolescents with low self-esteem</P></div>
                                <div class="list-group-item"><p>Adolescents with low self-confidence</p></div>
                                <div class="list-group-item"><p>Adolescents that lack a sense of direction.</p></div>
                                <div class="list-group-item"><p>Adolescents with difficulty in a parent-child relationship</p></div>
                                <div class="list-group-item"><p>Adolescents with difficulty in a teacher-student relationship</p></div>
                                <div class="list-group-item"><p>Adolescents with abuse and assault history</p></div>
                                <div class="list-group-item"><p>Adolescents with poor socialization skills</p></div>
                                <div class="list-group-item"><p>Adolescents considered to be a dullard</p></div>
                            </ul>
                            <p><h3>Our Belief</h4><p>
                            <p class="lead">Human Capacity Development</p>
                            <p>
                                It is the collective knowledge, skill and other intangible assets of individuals.
                            </p>
                            <p>
                                A nation’s wealth is measured by the number of creative minds it harbours. Many adolescents
                                have hidden talents and potentials which are capable of been harnessed. Their potential 
                                when harnessed can boost the nation’s productivity and contribute significantly to the economic 
                                wellbeing of the nation. 
                            </p>
                            <p>
                                At polished Arrow, we believe education is the greatest human capital investment because it makes an 
                                individual more productive, efficient and creative. It brings exposure to the doorstep of an individual
                                thereby creating a sustainable society.
                            </p>
                        </div>
                    </div>
                </div>    
            <div class="section" id="about">
                <div class="container">
                    <div class="section-title">
                        <small>ABOUT US</small>
                        <h3>OUR PURPOSE</h3>
                        <ul class="list-group list-group-flush">
                            <div class="list-group-item">
                                    <li>
                                        <p>To provide our educational system with a support system that exposes the adolescent to real-life 
                                        situations so that they can begin to grow with its consciousness.</P>
                                    </li>
                                    <li>
                                        <p>
                                            To serve as s support system for students tagged “dull” or students with poor academic performance.
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                        	To afford intelligent adolescents the opportunities to develop and apply their multiple intelligence 
                                            constructively so that they and their immediate Society can benefit.
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            To reduce the help the society to reduce the incidences of school dropout or attempted to drop out. 
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            To positively impact adolescents affected by peer pressure, teenage pregnancy, depression, sexual abuse, 
                                            substance abuse, youth suicide, low self-esteem etc.
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            To provide a support system for adolescent during their transition into adulthood.
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            To explore human potential beyond the status quo
                                        </p>
                                    </li>
                            </div>        
                    </ul>
                        <h3>VISION STATEMENT:</h3>
                        <p>
                        To be a foremost solution to adolescence challenges across the world by raising 
                        a generation that will leverage on education and their natural abilities for 
                        self-advancement and sustainable DEVELOPMENT ACROSS THE GLOBE.
                        </p>
                        <h3>MISSION STATEMENT:</h3>
                        <p>
                            To create systems that are sensitive to the peculiarities of adolescents and 
                            provide relevant information needed for the formation of a healthy mind and a clear standard.
                        </p>
                    </div>    
                </div>

                <!-- // services -->
             <div class="section" id="services">
            <div class="container">
            <div class="section-title">
                <small>SERVICES</small>
                <h4>Our services aim at:</h4>
                <ul class="list-group list-group-flush">
                        <li>
                            <p>
                                Supporting and training students considered to be academically poor.
                            </p>
                            </li>
                            <li>
                            <p>
                                Supporting and equiping adolescents at risk of developmental disorder.
                            </p>
                            </li>
                            <li>
                            <p>
                                Supporting and developing adolescents during their transition process into adulthood.
                            </p>
                            </li>
                        </ul>
                        <h4>The services include:</h4>
            </div>
              <!-- // end.services -->
              
            <ul class="nav nav-tabs nav-justified" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#communication">Training</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#schedule">Conselling</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#messages">Consultation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#livechat">Academic Tutorials</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#coaching">Coaching Sections</a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="communication">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                        <div>
                            <p class="lead">for twenty-first-century teachers and educators</p>
                            <p>
                                This service can be rendered online and offline
                            </p>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="schedule">
                    <div class="d-flex flex-column flex-lg-row">
                        <div>
                            <p class="lead"> for adolescents and parents </p>
                            <p>
                                This service can be rendered online and offline
                            </p>
                        </div>
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                    </div>
                </div>
                <div class="tab-pane fade" id="messages">
                    <div class="d-flex flex-column flex-lg-row">
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                        <div>
                            <p class="lead">from a Psychological Consultant to adolescents</p>
                            <p>
                                This service can be rendered online and offline
                            </p>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="livechat">
                    <div class="d-flex flex-column flex-lg-row">
                        <div>
                            <p class="lead">Academic Tutorials</p>
                            <p>
                                Online and Offline academic tutorials: for adolescents
                            </p>
                        </div>
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                    </div>
                </div>
                <div class="tab-pane fade" id="coaching">
                    <div class="d-flex flex-column flex-lg-row">
                        <div>
                            <p class="lead">Coaching Sections</p>
                            <p>
                                Online and Offline coaching sections: for adolescents
                            </p>
                        </div>
                        <img src="images/graphic.png" alt="graphic" class="img-fluid rounded align-self-start mr-lg-5 mb-5 mb-lg-0">
                    </div>
                </div>
            </div>


        </div>
    </div>
    

            </div>
             
            </div>
            <!-- // end .section -->

            <div class="light-bg py-5" id="contact">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 text-center text-lg-left">
                        <div class="d-block d-sm-inline-block">
                                <p class="mb-0">
                                    <span class="ti-headphone-alt mr-2"></span> <a href="#">Phone:</a>
                                </p>
                            </div>
                            <p class="mb-2"> <span class="ti-location-pin mr-2"></span>Address:</p>
                            <div class=" d-block d-sm-inline-block">
                                <p class="mb-2">
                                    <span class="ti-email mr-2"></span> <a class="mr-4" href="#">Email:</a>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="social-icons">
                                <a href="#"><span class="ti-facebook"></span></a>
                                <a href="#"><span class="ti-twitter-alt"></span></a>
                                <a href="#"><span class="ti-instagram"></span></a>
                            </div>
                        </div>
                    </div>

                </div>
        
            <!-- // end .section -->
  
    <?php include "footer.php"?> 
    <!-- jQuery and Bootstrap -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <!-- Plugins JS -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- Custom JS -->
    <script src="js/script.js"></script>
</body>

</html>

